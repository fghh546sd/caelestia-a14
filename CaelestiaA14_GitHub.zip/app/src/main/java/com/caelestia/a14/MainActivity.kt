package com.caelestia.a14

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2

/** Launcher kiểu Caelestia: 3 workspace (Home / Apps / Quick settings), tông Material tối-tím. */
class MainActivity : AppCompatActivity() {
    private val bg = 0xFF141218.toInt()
    private val card = 0xFF211F26.toInt()
    private val fg = 0xFFE6E0E9.toInt()
    private val accent = 0xFFD0BCFF.toInt()
    private lateinit var pager: ViewPager2

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, r: Int = 24) =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun su(cmd: String) = Thread {
        try { Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).waitFor() } catch (_: Exception) {}
    }.start()

    private fun tv(text: CharSequence, size: Float, color: Int = fg, mono: Boolean = false) =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (mono) typeface = Typeface.MONOSPACE
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        pager = ViewPager2(this)
        pager.setBackgroundColor(bg)
        pager.adapter = PageAdapter()
        pager.offscreenPageLimit = 2
        setContentView(pager)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        pager.currentItem = 0 // bấm Home -> về workspace 1
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() { pager.currentItem = 0 }

    inner class PageAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = 3
        override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
            val f = FrameLayout(p.context)
            f.layoutParams = ViewGroup.LayoutParams(-1, -1)
            return object : RecyclerView.ViewHolder(f) {}
        }
        override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
            val f = h.itemView as FrameLayout
            f.removeAllViews()
            f.addView(when (pos) { 0 -> home(); 1 -> drawer(); else -> quick() })
        }
    }

    // ---- Workspace 1: đồng hồ + fastfetch + dock ----
    private fun home(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        col.addView(TextClock(this).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"; textSize = 72f; setTextColor(accent)
        })
        col.addView(TextClock(this).apply {
            format24Hour = "EEEE, d MMMM"; format12Hour = "EEEE, d MMMM"; textSize = 18f; setTextColor(fg)
        })
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val info = "caelestia@${Build.MODEL}\n" +
            "device  ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "android ${Build.VERSION.RELEASE}\n" +
            "kernel  ${System.getProperty("os.version")}\n" +
            "ram     ${(mi.totalMem - mi.availMem) / 1048576}/${mi.totalMem / 1048576} MB\n" +
            "uptime  ${SystemClock.elapsedRealtime() / 60000} min"
        val fetch = tv(info, 13f, accent, true).apply {
            setPadding(dp(20), dp(16), dp(20), dp(16)); background = rounded(card)
        }
        col.addView(fetch, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(32) })
        col.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))

        val dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(12), dp(8), dp(12)); background = rounded(card, 32)
        }
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        for (i in intents) {
            val ri = packageManager.resolveActivity(i, 0) ?: continue
            dock.addView(ImageView(this).apply {
                setImageDrawable(ri.loadIcon(packageManager))
                setOnClickListener { startActivity(i) }
            }, LinearLayout.LayoutParams(0, dp(52), 1f))
        }
        col.addView(dock, LinearLayout.LayoutParams(-1, -2))
        return col
    }

    // ---- Workspace 2: App drawer ----
    private fun drawer(): View {
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(main, 0)
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        val rv = RecyclerView(this)
        rv.layoutManager = GridLayoutManager(this, 4)
        rv.setPadding(dp(8), dp(24), dp(8), dp(8)); rv.clipToPadding = false
        rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = apps.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
                val c = LinearLayout(p.context).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(dp(4), dp(10), dp(4), dp(10))
                    layoutParams = RecyclerView.LayoutParams(-1, -2)
                }
                c.addView(ImageView(p.context).apply { id = 1 }, LinearLayout.LayoutParams(dp(48), dp(48)))
                c.addView(TextView(p.context).apply {
                    id = 2; textSize = 11f; setTextColor(fg); maxLines = 1
                    gravity = Gravity.CENTER; ellipsize = TextUtils.TruncateAt.END
                })
                return object : RecyclerView.ViewHolder(c) {}
            }
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                val ri = apps[pos]
                h.itemView.findViewById<ImageView>(1).setImageDrawable(ri.loadIcon(packageManager))
                h.itemView.findViewById<TextView>(2).text = ri.loadLabel(packageManager)
                h.itemView.setOnClickListener {
                    packageManager.getLaunchIntentForPackage(ri.activityInfo.packageName)?.let { startActivity(it) }
                }
            }
        }
        return rv
    }

    // ---- Workspace 3: Quick settings (cần root) ----
    private fun quick(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        col.addView(tv("Quick settings", 24f, accent))
        fun toggle(label: String, on: String, off: String) {
            val s = Switch(this).apply {
                text = label; textSize = 16f; setTextColor(fg)
                setPadding(dp(16), dp(16), dp(16), dp(16)); background = rounded(card)
                setOnCheckedChangeListener { _, c -> su(if (c) on else off) }
            }
            col.addView(s, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        }
        toggle("Wi-Fi", "svc wifi enable", "svc wifi disable")
        toggle("Dữ liệu di động", "svc data enable", "svc data disable")
        toggle("Bluetooth", "svc bluetooth enable", "svc bluetooth disable")
        col.addView(Button(this).apply {
            text = "Respring (khởi động lại SystemUI)"
            setOnClickListener { su("pkill -f com.android.systemui") }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })
        return col
    }
}
